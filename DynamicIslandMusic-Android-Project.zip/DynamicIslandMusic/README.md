# Dynamic Island Music (Android)

Project Android native (Kotlin), bukan HTML. Target minimal Android 8.0 (API 26), cocok untuk Android 10.

## Fitur
- Island hitam mengambang di bagian atas layar melalui `SYSTEM_ALERT_WINDOW`.
- Membaca sesi media aktif melalui Notification Listener.
- Menampilkan judul/artis dan kontrol previous, play/pause, next.
- UI dibuat native tanpa framework tambahan agar ringan.

## Build APK
1. Buka folder `DynamicIslandMusic` melalui Android Studio (Hedgehog atau lebih baru).
2. Tunggu Gradle sync dan pastikan Android SDK 35 serta JDK 17 terpasang.
3. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. APK debug akan dibuat di `app/build/outputs/apk/debug/app-debug.apk`.

## Penggunaan di HP
1. Instal APK.
2. Buka aplikasi dan izinkan **Tampil di atas aplikasi lain**.
3. Izinkan **Akses notifikasi** untuk Dynamic Island Music.
4. Kembali ke aplikasi, tekan **Aktifkan Dynamic Island**.
5. Putar musik dari YouTube Music, Spotify, pemutar musik lokal, atau aplikasi yang menyediakan Android MediaSession.
6. Ketuk island untuk membuka kontrol.

Catatan: beberapa aplikasi musik atau versi Android dapat membatasi metadata/kontrol media. Izin akses notifikasi dibutuhkan untuk mendeteksi sesi media aktif. Untuk menutup island, buka aplikasi lalu tekan Matikan Dynamic Island atau paksa berhenti aplikasinya.
