package com.example.dynamicislandmusic

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class IslandOverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var root: LinearLayout
    private lateinit var titleView: TextView
    private lateinit var artistView: TextView
    private lateinit var playView: TextView
    private var expanded = false
    private val handler = Handler(Looper.getMainLooper())
    private val refresh = object : Runnable { override fun run() { updateContent(); handler.postDelayed(this, 1200) } }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        buildIsland()
        MediaBridge.onChanged = { handler.post { updateContent() } }
        try {
            wm.addView(root, params())
            handler.post(refresh)
        } catch (_: Exception) { stopSelf() }
    }

    private fun pill(bg: Int, radius: Float = 48f) = GradientDrawable().apply {
        setColor(bg); cornerRadius = dp(radius).toFloat()
        setStroke(dp(1), 0xFF292D32.toInt())
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); gravity = Gravity.CENTER_VERTICAL
        if (bold) setTypeface(typeface, Typeface.BOLD)
        maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END
    }

    private fun buildIsland() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = pill(Color.BLACK, 34f)
            setPadding(dp(13), dp(9), dp(13), dp(9))
            elevation = dp(12).toFloat()
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val dot = TextView(this).apply {
            text = "♫"; textSize = 19f; gravity = Gravity.CENTER; setTextColor(0xFF8CF0C8.toInt())
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFF183B30.toInt()) }
        }
        top.addView(dot, LinearLayout.LayoutParams(dp(39), dp(39)))
        val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, dp(8), 0) }
        titleView = text("Belum ada musik", 12f, Color.WHITE, true)
        artistView = text("Putar musik untuk mulai", 10f, 0xFF9DA4AE.toInt())
        labels.addView(titleView); labels.addView(artistView)
        top.addView(labels, LinearLayout.LayoutParams(0, dp(42), 1f))
        val bars = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; }
        listOf(7, 14, 10, 18, 8).forEachIndexed { i, h ->
            val bar = View(this).apply { setBackgroundColor(0xFF8CF0C8.toInt()); alpha = if (i % 2 == 0) .95f else .65f }
            bars.addView(bar, LinearLayout.LayoutParams(dp(3), dp(h)).apply { leftMargin = dp(2); rightMargin = dp(2) })
        }
        top.addView(bars, LinearLayout.LayoutParams(dp(32), dp(38)))
        root.addView(top)
        top.setOnClickListener { expanded = !expanded; rebuildExpanded() }
        root.setOnClickListener { expanded = !expanded; rebuildExpanded() }
        rebuildExpanded()
    }

    private fun rebuildExpanded() {
        while (root.childCount > 1) root.removeViewAt(1)
        if (expanded) {
            val controls = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
                setPadding(0, dp(10), 0, dp(1))
            }
            fun control(label: String, action: () -> Unit): TextView = text(label, 20f, Color.WHITE, true).apply {
                gravity = Gravity.CENTER; setOnClickListener { action(); updateContent() }
            }
            controls.addView(control("|◀") { MediaBridge.previous() }, LinearLayout.LayoutParams(dp(65), dp(43)))
            playView = control("Ⅱ") { MediaBridge.toggle() }
            controls.addView(playView, LinearLayout.LayoutParams(dp(65), dp(43)))
            controls.addView(control("▶| ") { MediaBridge.next() }, LinearLayout.LayoutParams(dp(65), dp(43)))
            root.addView(controls)
        }
        try { wm.updateViewLayout(root, params()) } catch (_: Exception) {}
    }

    private fun params() = WindowManager.LayoutParams(
        if (expanded) dp(280) else dp(238),
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        android.graphics.PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = dp(5) }

    private fun updateContent() {
        if (!::root.isInitialized) return
        titleView.text = MediaBridge.title
        artistView.text = MediaBridge.artist
        if (expanded && ::playView.isInitialized) playView.text = if (MediaBridge.playing) "Ⅱ" else "▶"
    }

    override fun onDestroy() {
        handler.removeCallbacks(refresh)
        MediaBridge.onChanged = null
        try { if (::root.isInitialized) wm.removeView(root) } catch (_: Exception) {}
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
