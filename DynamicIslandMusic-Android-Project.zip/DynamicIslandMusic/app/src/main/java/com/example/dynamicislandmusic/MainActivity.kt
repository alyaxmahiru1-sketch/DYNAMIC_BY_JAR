package com.example.dynamicislandmusic

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(28), dp(24), dp(28))
            setBackgroundColor(0xFF08090D.toInt())
        }
        root.addView(TextView(this).apply {
            text = "♫  Dynamic Island Music"
            textSize = 25f; setTextColor(0xFFFFFFFF.toInt()); gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, dp(64)))
        root.addView(TextView(this).apply {
            text = "Island musik mengambang untuk Android. Aktifkan dua izin di bawah agar judul lagu dan kontrol pemutar bisa tampil di atas aplikasi lain."
            textSize = 14f; setTextColor(0xFFADB4BF.toInt()); gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, dp(100)))
        fun addButton(label: String, action: () -> Unit) {
            root.addView(Button(this).apply { text = label; setOnClickListener { action() } },
                LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(10) })
        }
        addButton("1. Izinkan tampil di atas aplikasi lain") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        }
        addButton("2. Izinkan akses notifikasi / media") {
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        }
        addButton("Aktifkan Dynamic Island") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else if (!isNotificationAccessEnabled()) {
                startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
            } else {
                startService(Intent(this, IslandOverlayService::class.java))
            }
        }
        addButton("Matikan Dynamic Island") { stopService(Intent(this, IslandOverlayService::class.java)) }
        root.addView(TextView(this).apply {
            text = "Catatan: tampilkan izin notifikasi untuk membaca sesi media. Musik tetap diputar oleh aplikasi musik pilihanmu."
            textSize = 12f; setTextColor(0xFF777F8B.toInt()); gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, dp(76)))
        setContentView(root)
    }

    private fun isNotificationAccessEnabled(): Boolean {
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        val cn = ComponentName(this, MediaAccessService::class.java)
        return flat.split(":").any { TextUtils.equals(it, cn.flattenToString()) }
    }
}
