package com.example.dynamicislandmusic

import android.content.Context
import android.media.session.MediaSessionManager
import android.media.session.MediaController
import android.media.session.PlaybackState
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class MediaAccessService : NotificationListenerService() {
    override fun onListenerConnected() {
        super.onListenerConnected()
        refreshSessions()
    }
    override fun onNotificationPosted(sbn: StatusBarNotification?) { refreshSessions() }
    override fun onNotificationRemoved(sbn: StatusBarNotification?) { refreshSessions() }

    private fun refreshSessions() {
        try {
            val manager = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val sessions = manager.getActiveSessions(MediaAccessService.component(this))
            val controller = sessions.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
                ?: sessions.firstOrNull()
            MediaBridge.setController(controller)
        } catch (_: SecurityException) { MediaBridge.setController(null) }
        catch (_: Exception) { MediaBridge.setController(null) }
    }

    companion object {
        fun component(context: Context) = android.content.ComponentName(context, MediaAccessService::class.java)
    }
}
