package com.example.dynamicislandmusic

import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.PlaybackState

object MediaBridge {
    @Volatile private var controller: MediaController? = null
    @Volatile var title: String = "Belum ada musik"; private set
    @Volatile var artist: String = "Putar musik di aplikasi pilihanmu"; private set
    @Volatile var playing: Boolean = false; private set
    private var callback: MediaController.Callback? = null
    @Volatile var onChanged: (() -> Unit)? = null

    @Synchronized fun setController(next: MediaController?) {
        if (controller == next) { refresh(); return }
        try { callback?.let { controller?.unregisterCallback(it) } } catch (_: Exception) {}
        controller = next
        callback = object : MediaController.Callback() {
            override fun onMetadataChanged(metadata: MediaMetadata?) = refresh()
            override fun onPlaybackStateChanged(state: PlaybackState?) = refresh()
            override fun onSessionDestroyed() { setController(null) }
        }
        try { controller?.registerCallback(callback!!) } catch (_: Exception) {}
        refresh()
    }

    @Synchronized fun refresh() {
        val c = controller
        val md = c?.metadata
        title = md?.getString(MediaMetadata.METADATA_KEY_TITLE)?.takeIf { it.isNotBlank() } ?: "Belum ada musik"
        artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST)?.takeIf { it.isNotBlank() }
            ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)?.takeIf { it.isNotBlank() }
            ?: "Putar musik di aplikasi pilihanmu"
        playing = c?.playbackState?.state == PlaybackState.STATE_PLAYING
        onChanged?.invoke()
    }
    fun toggle() {
        val c = controller ?: return
        if (playing) c.transportControls.pause() else c.transportControls.play()
        refresh()
    }
    fun next() { controller?.transportControls?.skipToNext() }
    fun previous() { controller?.transportControls?.skipToPrevious() }
}
